# Changelog

## R1.10 — Bootstrap AppBase + Gestor de Tarefas
- AppBase com i18n (PT/EN/ES) e CSS centralizado
- MiniApp Gestor de Tarefas (tabela editável)
- GitHub Pages + Preview (staging) + CI leve
