export const flags = { demo: true };
