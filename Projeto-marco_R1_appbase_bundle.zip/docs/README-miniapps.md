# Contrato de MiniApps (R1)

- Entregar: `manifest.json`, `i18n-snippet.json`, `app.html` (**sem CSS próprio**).
- Namespace i18n: `miniapps.<id>.*`.
- Idiomas: `pt-br`, `en-us`, `es-419`.
- CSS: usar apenas utilitários/componentes do AppBase e tokens `--ac-*`.
